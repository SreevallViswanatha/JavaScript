"use strict";

class App {
  #tasksShandilya;
  #tasksAaditya;
  #shandilyaTasksContainer;
  #aadityaTasksContainer;
  #container;
  constructor() {
    this.#getData();
    this.#addTasks();
    this.#container = document.querySelector(".container");
    this.#shandilyaTasksContainer = document.querySelector(".shandilya-tasks");
    this.#aadityaTasksContainer = document.querySelector(".aaditya-tasks");
    this.#container.addEventListener("click", this.#showTasks);
    this.#shandilyaTasksContainer.addEventListener(
      "click",
      this.#goToShandilyasResults.bind(this)
    );
    this.#aadityaTasksContainer.addEventListener(
      "click",
      this.#goToAadityasResults.bind(this)
    );
  }

  #getData() {
    this.#tasksShandilya = [
      "Node JS",
      "MySQL",
      "Bootstrap",
      "JavaScript",
      "C#",
      "Data Structures",
      "AMC Trivial",
      "AoPS Volume 2",
      "IIT Physics",
      "Physics AoPS",
      "Fundamentals of Physics",
    ];
    this.#tasksAaditya = [
      "MySQL",
      "Node JS",
      "Bootstrap",
      "JavaScript",
      "Excel",
      "Srikanth Sir C",
      "Pointers",
      "IXL",
      "Physics FoP",
      "Science",
      "AMC Trivial",
      "MOEMS",
      "Geometry",
      "Counting and Probability",
      "Number Theory",
      "Kumon Math",
      "Kumon Reading",
      "Spellings",
      "Easy Grammar",
    ];
  }

  #addTasks() {
    const shandilyaHeadingRow = document.querySelector(".shandilya-heading");
    const aadityaHeadingRow = document.querySelector(".aaditya-heading");
    this.#tasksShandilya.forEach((task, i) => {
      const currentIndex = this.#tasksShandilya.length - i;
      shandilyaHeadingRow.insertAdjacentHTML(
        "afterend",
        `<div class="row justify-content-center linkclass">
           <div class="col col-1">${currentIndex}</div>
           <div class="col col-6 task">${task}</div>
         </div>`
      );
    });
    this.#tasksAaditya.forEach((task, i) => {
      const currentIndex = this.#tasksAaditya.length - i;
      aadityaHeadingRow.insertAdjacentHTML(
        "afterend",
        `<div class="row justify-content-center linkclass">
      <div class="col col-1">${currentIndex}</div>
      <div class="col col-6 task">${task}</div>
    </div>`
      );
    });
  }

  #showTasks(e) {
    const showButton = e.target.closest(".show-button");
    if (!showButton) return;
    const toDoTasks = showButton.closest(".row").querySelector(".tasks");
    toDoTasks.classList.toggle("hidden");
    if (showButton.textContent === "+") showButton.textContent = "-";
    else showButton.textContent = "+";
  }

  #goToShandilyasResults(e) {
    this.#goToResults("Shandilya", e);
  }

  #goToAadityasResults(e) {
    this.#goToResults("Aaditya", e);
  }

  #goToResults(name, e) {
    const taskName = e.target
      .closest(".row")
      .querySelector(".task")
      .textContent.split(" ")
      .join("");
    const url = `${window.location.href.split("/")[0]}//${
      window.location.href.split("/")[2]
    }/admin/tasks/course/index.html?${name}+${taskName}`;
    window.open(url, "_blank");
  }
}

const app = new App();
