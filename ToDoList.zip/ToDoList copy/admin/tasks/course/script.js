"use strict";

const headingRow = document.querySelector(".heading-row");
const table = document.querySelector("table");

class Tasks {
  #dates = [];
  #works = [];
  #startTimes = [];
  #endTimes = [];
  #timeElapsed = [];
  #timeTaken = [];
  #results = [];
  #initials = [];
  #currentDate;
  #person;
  #task;
  constructor() {
    this.#currentDate = this.#createDate(new Date());
    this.#getPerson();
    this.#getTask();
    this.#changeHeading();
    this.#getData();
    this.#displayTable();
    table.addEventListener("click", this.#goToResults);
  }

  #getPerson() {
    this.#person = window.location.href.split("?").slice(-1)[0].split("+")[0];
    console.log(this.#person);
  }

  #getTask() {
    this.#task = window.location.href.split("?").slice(-1)[0].split("+")[1];
    console.log(this.#task);
  }

  #changeHeading() {
    const h1 = document.querySelector("h1");
    h1.textContent = `${this.#task}`;
  }

  #createDate(date) {
    const formattedDate = `${`${date.getMonth() + 1}`.padStart(
      2,
      0
    )}/${`${date.getDate()}`.padStart(2, 0)}/${date.getFullYear()}`;
    return formattedDate;
  }

  #getData() {
    // Dummy data, need to get real data from db
    this.#dates = [
      "08/20/2023",
      "08/19/2023",
      "08/18/2023",
      "08/17/2023",
      "08/16/2023",
      "08/15/2023",
      "08/14/2023",
      "08/13/2023",
      "08/12/2023",
      "08/11/2023",
      "08/10/2023",
      "08/09/2023",
      "08/08/2023",
      "08/07/2023",
      "08/06/2023",
      "08/05/2023",
      "08/04/2023",
      "08/03/2023",
      "08/02/2023",
      "08/01/2023",
    ];
    this.#createNextWeeksDates();
    this.#works = [
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
      "Ch 8, P 1-15",
    ];
    this.#startTimes = [
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:30 AM",
      "7:31 AM",
      "7:31 AM",
      "7:31 AM",
      "7:31 AM",
      "7:31 AM",
      "7:31 AM",
    ];
    this.#endTimes = [
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:10 AM",
      "9:11 AM",
      "9:11 AM",
      "9:11 AM",
      "9:11 AM",
      "9:11 AM",
      "9:11 AM",
    ];
    this.#timeElapsed = [
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
      "01:40:00",
    ];
    this.#timeTaken = [
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
      "02:00:00",
    ];
    this.#results = [
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
      "No R",
    ];
    this.#initials = [
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
      "A. N.",
    ];
  }

  #displayTable() {
    this.#dates.forEach((date, i) => {
      const currentIndex = this.#dates.length - i - 1;
      const didNotDoText = "";
      headingRow.insertAdjacentHTML(
        "afterend",
        `<tr class="table-row-${this.#checkIfAllowed(date) ? "" : "in"}active">
            <td class="date">${date}</td>
            <td>${this.#works[currentIndex] || didNotDoText}</td>
            <td>${this.#startTimes[currentIndex] || didNotDoText}</td>
            <td>${this.#endTimes[currentIndex] || didNotDoText}</td>
            <td>${this.#timeElapsed[currentIndex] || didNotDoText}</td>
            <td>${this.#timeTaken[currentIndex] || didNotDoText}</td>
            <td>${this.#results[currentIndex] || didNotDoText}</td>
            <td>${this.#initials[currentIndex] || didNotDoText}</td>
          </tr>`
      );
    });
  }

  #checkIfAllowed(date) {
    const [currentMonth, currentDay, currentYear] = this.#currentDate
      .split("/")
      .map((el) => +el);
    const [dateMonth, dateDay, dateYear] = date.split("/").map((el) => +el);
    if (dateYear < currentYear) return 0;
    if (dateMonth < currentMonth) return 0;
    if (dateDay < currentDay) return 0;
    return 1;
  }

  #goToResults(e) {
    const tableRow = e.target.closest("tr");
    if (tableRow.classList.contains("table-row-inactive")) return;
    const date = tableRow
      .querySelector(".date")
      .textContent.split("/")
      .join("-");
    const url = `${window.location.href.split("/")[0]}//${
      window.location.href.split("/")[2]
    }/admin/tasks/course/enter/index.html?${window.location.href
      .split("?")
      .slice(1, 2)}+${date}`;
    window.open(url, "_blank");
  }

  #createNextWeeksDates() {
    for (let i = 0; i <= 6; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const formattedDate = this.#createDate(date);
      this.#dates.unshift(formattedDate);
    }
  }
}

const tasks = new Tasks();
