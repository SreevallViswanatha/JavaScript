"use strict";

class App {
  #container;
  #person;
  #tasks = [];
  constructor() {
    this.#container = document.querySelector(".container");
    this.#getPerson();
    this.#changeHeading();
    this.#getData();
    this.#generateTable();
    this.#container.addEventListener("click", this.#goToCourse.bind(this));
  }

  #getPerson() {
    this.#person = window.location.href.split("?").slice(-1)[0];
    console.log(this.#person);
  }

  #changeHeading() {
    const h1 = document.querySelector("h1");
    h1.textContent = `${this.#person}'s todo tasks for the day`;
  }

  #getData() {
    // Need to get from database using this.#person
    this.#tasks = [
      "Node JS",
      "MySQL",
      "Bootstrap",
      "JavaScript",
      "C#",
      "Data Structures",
      "AMC Trivial",
      "AoPS Volume 2",
      "IIT Physics",
      "Physics AoPS",
      "Fundamentals of Physics",
    ];
  }

  #generateTable() {
    const headingRow = document.querySelector(".my-row");
    this.#tasks.forEach((task, i) => {
      const currentIndex = this.#tasks.length - i;
      headingRow.insertAdjacentHTML(
        "afterend",
        `<div class="row justify-content-center linkclass">
           <div class="col col-1">${currentIndex}</div>
           <div class="col col-6 task">${task}</div>
         </div>`
      );
    });
  }

  #goToCourse(e) {
    const taskName = e.target
      .closest(".row")
      .querySelector(".task")
      .textContent.split(" ")
      .join("_");
    const url = `${window.location.href.split("/")[0]}//${
      window.location.href.split("/")[2]
    }/student/tasks/course/index.html?${window.location.href
      .split("?")
      .slice(1, 2)}+${taskName}`;
    window.open(url, "_blank");
  }
}

const app = new App();
