"use strict";

class App {
  #person;
  #task;
  #date;
  #startTimer;
  #pauseTimer;
  #endTimer;
  #startPauseTimerCell;
  #time1 = 0;
  #time2 = 0;
  #timer1;
  #timer2;
  #accessible = 1;
  constructor() {
    this.#getPerson();
    this.#getTask();
    this.#getDate();
    this.#generateList();
    this.#startTimer = document.querySelector(".start-timer");
    this.#pauseTimer = document.querySelector(".pause-timer");
    this.#endTimer = document.querySelector(".end-timer");
    this.#startPauseTimerCell = this.#startTimer.closest("td");
    this.#startTimer.addEventListener(
      "click",
      this.#startTimerHandler.bind(this)
    );
    this.#pauseTimer.addEventListener(
      "click",
      this.#pauseTimerHandler.bind(this)
    );
    this.#endTimer.addEventListener("click", this.#endTimerHandler.bind(this));
    this.#startPauseTimerCell.addEventListener(
      "click",
      this.#toggleIcons.bind(this)
    );
  }

  #getPerson() {
    this.#person = window.location.href.split("?").slice(-1)[0].split("+")[0];
    console.log(this.#person);
  }

  #getTask() {
    this.#task = window.location.href.split("?").slice(-1)[0].split("+")[1];
    console.log(this.#task);
  }

  #getDate() {
    this.#date = window.location.href
      .split("+")
      .slice(-1)[0]
      .split("?")
      .slice(-1)[0]
      .split("-")
      .join("/");
  }

  #generateList() {
    const tableBody = document.querySelector("tbody");
    tableBody.insertAdjacentHTML(
      "afterbegin",
      `<tr>
      <td class="starting-cell">Date</td>
      <td>${this.#date}</td>
      </tr>`
    );
  }

  #startTimerHandler() {
    const timeTaken = document.querySelector(".time-taken");
    if (this.#accessible) {
      const startTime = document.querySelector(".start-time");
      const timeElapsed = document.querySelector(".time-elapsed");
      startTime.textContent = this.#formatTime(new Date());
      this.#tick(1, timeElapsed);
      this.#timer1 = setInterval(this.#tick.bind(this), 1000, 1, timeElapsed);
      this.#endTimer.classList.remove("btn-disable");
      this.#endTimer.disabled = false;
      this.#accessible = 0;
    }
    this.#tick(2, timeTaken);
    this.#timer2 = setInterval(this.#tick.bind(this), 1000, 2, timeTaken);
  }

  #pauseTimerHandler() {
    clearInterval(this.#timer2);
  }

  #endTimerHandler() {
    let flag;
    const endTime = document.querySelector(".end-time");
    const inputs = document.querySelectorAll(".input-disabled");
    const completeTaskButton = document.querySelector(".complete-task");
    const modalBody = document.querySelector(".modal-body");
    endTime.textContent = this.#formatTime(new Date());
    clearInterval(this.#timer1);
    clearInterval(this.#timer2);
    this.#startTimer.disabled = true;
    this.#pauseTimer.disabled = true;
    this.#endTimer.disabled = true;
    this.#startTimer.classList.add("btn-disable");
    this.#pauseTimer.classList.add("btn-disable");
    this.#endTimer.classList.add("btn-disable");
    this.#startTimer.classList.remove("hidden");
    this.#pauseTimer.classList.add("hidden");
    inputs.forEach((input) => {
      input.classList.remove("input-disabled");
      input.disabled = false;
    });
    inputs[0].focus();
    completeTaskButton.classList.remove("btn-disable");
    completeTaskButton.disabled = false;
    completeTaskButton.classList.add("btn-primary");
    completeTaskButton.addEventListener("click", function () {
      flag = 1;
      inputs.forEach((input) => {
        if (input.value === "") {
          modalBody.textContent =
            "You haven't filled out some of the required fields (Results and/or Initials). Make sure you fill them before clicking on this button!";
          flag = 0;
        }
      });
      if (flag) {
        // Remember to update database here
        inputs.forEach((input) => {
          input.classList.add("input-disabled");
          input.disabled = true;
        });
        modalBody.textContent =
          "Your changes have been saved! You can close this tab now!";
        modalBody.classList.remove("failure-text");
        modalBody.classList.add("success-text");
        completeTaskButton.classList.add("btn-disable");
        completeTaskButton.disabled = true;
        completeTaskButton.classList.remove("btn-primary");
      }
    });
  }

  #tick(timerNumber, timeContainer) {
    if (timerNumber === 1) {
      timeContainer.textContent = `${`${Math.trunc(
        this.#time1 / 3600
      )}`.padStart(2, 0)}:${`${Math.trunc((this.#time1 / 60) % 60)}`.padStart(
        2,
        0
      )}:${`${this.#time1 % 60}`.padStart(2, 0)}`;
      this.#time1++;
    } else {
      timeContainer.textContent = `${`${Math.trunc(
        this.#time2 / 3600
      )}`.padStart(2, 0)}:${`${Math.trunc((this.#time2 / 60) % 60)}`.padStart(
        2,
        0
      )}:${`${this.#time2 % 60}`.padStart(2, 0)}`;
      this.#time2++;
    }
  }

  #toggleIcons(e) {
    const button = e.target.closest("button");
    if (!button) return;
    if (button.classList.contains("btn-disable")) return;
    this.#startTimer.classList.toggle("hidden");
    this.#pauseTimer.classList.toggle("hidden");
  }

  #formatTime(date) {
    return `${
      date.getHours() > 12 ? date.getHours() - 12 : date.getHours()
    }:${`${date.getMinutes()}`.padStart(2, 0)} ${
      date.getHours() >= 12 ? "PM" : "AM"
    }`;
  }
}

const app = new App();
