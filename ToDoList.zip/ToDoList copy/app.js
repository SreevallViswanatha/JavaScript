const SyncMySQL = require("sync-mysql");
const fs = require("fs");

const connection = new SyncMySQL({
  host: "localhost",
  user: "root",
  password: "Aaditya@10years2012",
  database: "tv_db",
});

try {
  const results = connection.query("SELECT * FROM series");
  fs.writeFileSync("data.json", JSON.stringify(results));
} catch (error) {
  console.error("Error executing query:", error);
} finally {
  connection.dispose();
}
